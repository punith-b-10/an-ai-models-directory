AI Model Directory - static site with models.json, index.html, styles.css, script.js
