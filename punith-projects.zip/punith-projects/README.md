# punith-projects

Contains two static projects: ai-models-directory and career-guidance.
