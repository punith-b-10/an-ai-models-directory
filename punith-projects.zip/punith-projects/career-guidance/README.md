Career Guidance - static client-side questionnaire demo
