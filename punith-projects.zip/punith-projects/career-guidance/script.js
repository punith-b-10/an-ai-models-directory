const btn = document.getElementById('suggestBtn');
const res = document.getElementById('result');

btn.addEventListener('click', () => {
  const skills = Array.from(document.querySelectorAll('input[name="skill"]:checked')).map(i=>i.value);
  const work = (document.querySelector('input[name="work"]:checked') || {}).value || '';

  // scoring: simple rule-based
  const scores = {
    'Machine Learning Engineer': 0,
    'Data Scientist': 0,
    'Frontend Developer': 0,
    'DevOps Engineer': 0,
    'Cybersecurity Analyst': 0
  };

  if(skills.includes('python')){ scores['Machine Learning Engineer'] += 2; scores['Data Scientist'] += 2; }
  if(skills.includes('math')){ scores['Data Scientist'] += 2; scores['Machine Learning Engineer'] += 1; }
  if(skills.includes('frontend')){ scores['Frontend Developer'] += 3; }
  if(skills.includes('devops')){ scores['DevOps Engineer'] += 3; }
  if(skills.includes('security')){ scores['Cybersecurity Analyst'] += 3; }

  if(work === 'research'){ scores['Machine Learning Engineer'] += 2; scores['Data Scientist'] += 2; }
  if(work === 'product'){ scores['Frontend Developer'] += 2; scores['DevOps Engineer'] += 1; }
  if(work === 'ops'){ scores['DevOps Engineer'] += 2; }
  if(work === 'security'){ scores['Cybersecurity Analyst'] += 2; }

  // small tie-breaker: prefer user-picked skills
  if(skills.length === 0 && !work){ res.innerHTML = '<p class="small">Please select at least one skill or interest to get suggestions.</p>'; return; }

  const sorted = Object.entries(scores).sort((a,b)=>b[1]-a[1]);
  const top = sorted.filter(([k,v])=>v === sorted[0][1]).map(([k])=>k);

  renderResult(top, scores);
});

function renderResult(top, scores){
  res.innerHTML = '';
  const h = document.createElement('div');
  h.innerHTML = `<strong>Top suggestion(s):</strong> ${top.join(', ')}`;
  res.appendChild(h);

  // brief descriptions
  const desc = {
    'Machine Learning Engineer': 'Build and productionize ML models. Learn ML libraries, model deployment, data pipelines.',
    'Data Scientist': 'Data analysis, statistics, visualization, and building models to extract insights.',
    'Frontend Developer': 'Build user interfaces using HTML/CSS/JS, frameworks, and focus on UX.',
    'DevOps Engineer': 'Work on infrastructure, CI/CD, monitoring, and cloud automation.',
    'Cybersecurity Analyst': 'Work on threat detection, vulnerability analysis, incident response.'
  };

  top.forEach(t => {
    const el = document.createElement('div');
    el.className = 'suggestion';
    el.innerHTML = `<strong>${t}</strong><p>${desc[t]}</p>`;
    res.appendChild(el);
  });

  // add learning next-steps
  const next = document.createElement('div');
  next.innerHTML = `<strong>Next steps:</strong>
    <ul>
      <li>Pick one top track and do a focused learning path (courses + 2 projects).</li>
      <li>Build small portfolio projects and add to your GitHub.</li>
      <li>For ML/Data: learn Python, ML libraries, and at least one deployment option.</li>
    </ul>`;
  res.appendChild(next);
}
